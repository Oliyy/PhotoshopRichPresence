var name = new SolidColor();
name.rgb.hexValue = 'hexString';