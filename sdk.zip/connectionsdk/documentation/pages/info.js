// JavaScript Document
var sdkTitleStringWithHTML = "Adobe<sup>&reg;</sup> Photoshop<sup>&reg;</sup> Connection SDK";
var sdkTitleString = "Photoshop Connection SDK";
var sdkTitleAdobeString = "Adobe Photoshop Connection SDK";
var appName = "Photoshop Connection";
var appString = "Adobe Photoshop";
var appWithVersion = "Adobe Photoshop CS5";
var flashBuilderVersion = "Adobe Flash Builder 4.5 Premium";
var appWithVersionWithHTML = "Adobe<sup>&reg;</sup> Photoshop<sup>&reg;</sup> CS5";
var flashBuilderVersionHTML = "Adobe<sup>&reg;</sup> Flash<sup>&reg;</sup> Builder<sup>&reg;</sup> 4.5 Premium";

document.title = sdkTitleString;
